#!/bin/bash -l
#PBS -l select=1:ncpus=1:mpiprocs=1:ngpus=1:ompthreads=1
#PBS -l walltime=24:00:00
#PBS -j oe
#PBS -N LiNiO2
#PBS -q gpu

#export OMP_PROC_BIND=spread
#export OMP_PLACES=threads
#OMP_PROC_BIND=true
#export OMP_NUM_THREADS=5

source  /work/jzhang/softwares/lammps_mace_v100/bin/activate

cd $PBS_O_WORKDIR

nlims=4
times='times'
if [[ -f  $times ]]; then
   iters=$(tail -n 1 $times)
else
   iters=0
fi
if [[ $iters -lt $nlims ]] ;then
	if [ "$iters" -eq 0 ]; then
                lmp -k on g 1 -sf kk -i input.lammps -v rest 1  1>> log 2>> err
        else
                lmp -k on g 1 -sf kk -i input.lammps -v rest 0  1>> log 2>> err
	fi
	iters=$[iters+1]
	echo $iters >>$times
else
        exit
fi
qsub <./job.sh
